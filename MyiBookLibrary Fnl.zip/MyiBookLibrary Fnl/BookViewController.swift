//
//  BookViewController.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

import UIKit

class BookViewController: UIViewController {
    @IBOutlet var btnShelfSwitch:UISwitch
    @IBOutlet var booktitleLabel:UILabel
    
    var cur_bookindex:NSInteger!
    var cur_bookElement:Book!
    var isShelfFlag:Bool!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cur_bookindex = DBManager.shareInstance()!.currentBookIndex
        var shelf_element = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(DBManager.shareInstance()!.currentShelfIndex) as Shelf
        cur_bookElement = shelf_element.booksArray.objectAtIndex(cur_bookindex) as Book
        booktitleLabel.text = cur_bookElement.bookName
        if(DBManager.shareInstance()!.currentShelfIndex > 0) {
            btnShelfSwitch.hidden = false
            isShelfFlag = true
        }else{
            btnShelfSwitch.hidden = true
            isShelfFlag = false
        }
    }
    
    override func viewWillAppear(animated: Bool)  {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // move to shelf's page
    @IBAction func onBackButton() {
        if(!isShelfFlag) {
            var shelf_element = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(DBManager.shareInstance()!.currentShelfIndex) as Shelf
            var unshelf_element = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(0) as Shelf
            shelf_element.booksArray.removeObject(cur_bookElement)
            unshelf_element.booksArray.addObject(cur_bookElement)
            DBManager.shareInstance()!.bookShelfArray.replaceObjectAtIndex(DBManager.shareInstance()!.currentShelfIndex, withObject: shelf_element)
            DBManager.shareInstance()!.bookShelfArray.replaceObjectAtIndex(0, withObject: unshelf_element)
            
        }
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    // changed book's property (if unshelf, book go to unshelf,if shelf, book remains in shelf)
    @IBAction func onSwitchShelf() {
        isShelfFlag = btnShelfSwitch.on
    }
}


