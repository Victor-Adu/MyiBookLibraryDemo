//
//  DBManager.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//


import Foundation

var instance:DBManager? = nil

class DBManager:NSObject {
    var bookShelfArray:NSMutableArray!
    var currentShelfIndex:NSInteger!
    var currentBookIndex:NSInteger!
    class func shareInstance() -> DBManager? {
        return instance;
    }
    init() {
        super.init()
        self.initialization()
        bookShelfArray = NSMutableArray.array()
        var unshelf_element = Shelf()
        unshelf_element.shelfName = "UnShelf"
        bookShelfArray.addObject(unshelf_element)
    }
    func initialization() {
        instance = self
    }
}
