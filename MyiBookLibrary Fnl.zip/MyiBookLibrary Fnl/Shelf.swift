//
//  ShelfElement.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

//Shelf Element
import Foundation
class Shelf:NSObject {
    var booksArray:NSMutableArray!
    var shelfName:NSString!
    init() {
        booksArray = NSMutableArray()
    }
    // Book is added in shelf
    func addBook(name : NSString) {
        var bookElement = Book()
        bookElement.bookName = name
        if(DBManager.shareInstance()!.currentShelfIndex == 0) {
            bookElement.inShelfFlag = false
        }
        booksArray.addObject(bookElement)
    }
    // Book is removed in shelf
    func deleteBook(index:NSInteger) {
        booksArray.removeObjectAtIndex(index)
    }
    // Book is changed in shelf
    func updateBook(index:NSInteger, name:NSString) {
        var bookElement = booksArray.objectAtIndex(index) as Book
        bookElement.bookName = name
        if(DBManager.shareInstance()!.currentShelfIndex == 0) {
            bookElement.inShelfFlag = false
        }
        booksArray.replaceObjectAtIndex(index, withObject: bookElement)
    }
}
