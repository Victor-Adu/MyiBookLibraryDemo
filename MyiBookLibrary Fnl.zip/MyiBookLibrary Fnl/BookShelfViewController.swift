//
//  BookShelfViewController.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

import UIKit

class BookShelfViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var btnPlus:UIButton
    @IBOutlet var shelf_tableView:UITableView
    @IBOutlet var shelf_titleLabel:UILabel
    @IBOutlet var btnLibrary:UIButton
    
    var curShelf_index:NSInteger!
    var curShelf_element:Shelf!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var nib = UINib(nibName: "ShelfCell", bundle: nil)
        
        shelf_tableView.registerNib(nib, forCellReuseIdentifier: "customCell")
        curShelf_index = DBManager.shareInstance()!.currentShelfIndex
        curShelf_element = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(curShelf_index) as Shelf
        shelf_titleLabel.text = curShelf_element.shelfName
        
        
    }
    
    override func viewWillAppear(animated: Bool)  {
        super.viewWillAppear(animated)
        self.reloadTableData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // update UITableView
    func reloadTableData() {
        shelf_tableView.reloadData()
    }
    // return book's count in shelf
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int) -> Int {
        return curShelf_element.booksArray.count;
    }
    // make tableView of books in shelf of Library
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell! {
        var cell:ShelfCell = tableView.dequeueReusableCellWithIdentifier("customCell") as ShelfCell
        
        var bookElement:Book = curShelf_element.booksArray.objectAtIndex(indexPath.row) as Book
        var strbookName = bookElement.bookName
        cell.booknameLabel.text = bookElement.bookName
        cell.book_index = indexPath.row
        cell.parentViewController = self
        return cell
    }
    // selected book  in shelf
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil);
        let bookVC : BookViewController = storyboard.instantiateViewControllerWithIdentifier("BookViewController") as BookViewController;
        DBManager.shareInstance()!.currentBookIndex = indexPath.row
        self.presentViewController(bookVC, animated: true, completion: nil)
        
        println("You selected cell #\(indexPath.row)!")
    }
    // move to library page
    @IBAction func onBackButton() {
        DBManager.shareInstance()!.bookShelfArray.replaceObjectAtIndex(curShelf_index, withObject: curShelf_element)
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    // add book in shelf
    @IBAction func onPlusButton() {
        var bookElement = Book()
        bookElement.bookName = "Book"
        curShelf_element.booksArray.addObject(bookElement)
        shelf_tableView.reloadData()
    }
    
}

