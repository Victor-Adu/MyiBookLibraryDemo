//
//  BookLibraryViewController.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

import UIKit

class BookLibraryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var btnPlus:UIButton
    @IBOutlet var libraray_tableView:UITableView
    
    var dbManager:DBManager!
    var _bAdding : Bool!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        _bAdding = false
        
        var nib = UINib(nibName: "LibraryCell", bundle: nil)
        
        libraray_tableView.registerNib(nib, forCellReuseIdentifier: "customCell")
    }
    
    override func viewWillAppear(animated: Bool)  {
        super.viewWillAppear(animated)
        self.reloadTableData()
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // update library tableView
    func reloadTableData() {
        libraray_tableView.reloadData()
    }
    // add shelf in library
    @IBAction func onPlusButton() {
        var shelfElement = Shelf()
        shelfElement.shelfName = "BookShelf"
        DBManager.shareInstance()!.bookShelfArray.addObject(shelfElement)
        libraray_tableView.reloadData()
    }
    // return shelf's count
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int) -> Int {
        return DBManager.shareInstance()!.bookShelfArray.count;
    }
    // make library table cells in using shelfs
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell! {
        let cellIdentifier = "customCell"
        var cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath:indexPath) as LibraryCell
        var shelfElement:Shelf = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(indexPath.row) as Shelf
        var strLibName = shelfElement.shelfName
        cell.shelfnameLabel.text = shelfElement.shelfName
        cell.shelf_index = indexPath.row
        cell.parentViewController = self
        return cell
    }
    // selected shelf in library
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil);
        let bookShelfVC : BookShelfViewController = storyboard.instantiateViewControllerWithIdentifier("BookShelfViewController") as BookShelfViewController;
        DBManager.shareInstance()!.currentShelfIndex = indexPath.row
        self.presentViewController(bookShelfVC, animated: true, completion: nil)
        
        println("You selected cell #\(indexPath.row)!")
    }
}
