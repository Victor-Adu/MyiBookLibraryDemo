//
//  ShelfCell.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

import Foundation
import  UIKit

class ShelfCell:UITableViewCell,UITextFieldDelegate {
    @IBOutlet var booknameLabel:UILabel!
    @IBOutlet var booknameTxt:UITextField!
    @IBOutlet var bookeditButton:UIButton!
    @IBOutlet var bookremoveButton:UIButton!
    
    var parentViewController:BookShelfViewController!
    var book_index:NSInteger!
    
    
    init(style: UITableViewCellStyle, reuseIdentifier: String!) {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
    }
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    // Book's name is changed
    @IBAction func onClickEditButton() {
        if(booknameTxt.hidden) {
            booknameTxt.hidden = false
            booknameLabel.hidden = true
        }else{
            booknameTxt.hidden = true
            booknameLabel.hidden = false
        }
    }
    // Book is removed
    @IBAction func onClickRemoveButton() {
        var bookElement:Book = parentViewController.curShelf_element.booksArray.objectAtIndex(book_index) as Book
        parentViewController.curShelf_element.booksArray.removeObject(bookElement)
        parentViewController.reloadTableData()
    }
    
    // Book's name is changed
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        if(booknameTxt.text.isEmpty) {
            booknameTxt.text = "BookShelf"
        }else{
            booknameLabel.text  = booknameTxt.text
        }
        booknameTxt.hidden = true
        booknameLabel.hidden = false
        textField.resignFirstResponder()
        var bookElement:Book = parentViewController.curShelf_element.booksArray.objectAtIndex(book_index) as Book
        bookElement.bookName = booknameTxt.text
        parentViewController.reloadTableData()
        return true;
    }
}
