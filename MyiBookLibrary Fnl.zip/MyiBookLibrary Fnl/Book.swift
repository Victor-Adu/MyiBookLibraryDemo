//
// Book.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

//Book Element
import Foundation
class Book:NSObject {
    var bookName:NSString!
    var inShelfFlag:Bool
    init() {
        bookName = ""
        inShelfFlag = true
    }
}
