//
//  LibraryCell.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//

import Foundation
import  UIKit

class LibraryCell:UITableViewCell,UITextFieldDelegate {
    @IBOutlet var shelfnameLabel:UILabel
    @IBOutlet var shelfnameTxt:UITextField
    @IBOutlet var shelfeditButton:UIButton
    @IBOutlet var shelfremoveButton:UIButton
    
    var parentViewController:BookLibraryViewController!
    var shelf_index:NSInteger!
    init(style: UITableViewCellStyle, reuseIdentifier: String!) {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
    }
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
    // Shelf's name is changed.
    
    @IBAction func onClickEditButton() {
        if(shelf_index > 0) {
            if(shelfnameTxt.hidden) {
                shelfnameTxt.hidden = false
                shelfnameLabel.hidden = true
            }else{
                shelfnameTxt.hidden = true
                shelfnameLabel.hidden = false
            }
        }
    }
    // Shelf is removed shelf_index = 0 is unshelf. unshelf can be removed
    @IBAction func onClickRemoveButton() {
        if(shelf_index > 0) {
            var shelfElement:Shelf = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(shelf_index) as Shelf
            DBManager.shareInstance()!.bookShelfArray.removeObject(shelfElement)
            parentViewController.reloadTableData()
        }
        
    }
    // Shelf's name is changed
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        if(shelfnameTxt.text.isEmpty) {
            shelfnameTxt.text = "BookShelf"
        }else{
            shelfnameLabel.text  = shelfnameTxt.text
        }
        shelfnameTxt.hidden = true
        shelfnameLabel.hidden = false
        textField.resignFirstResponder()
        var shelfElement:Shelf = DBManager.shareInstance()!.bookShelfArray.objectAtIndex(shelf_index) as Shelf
        shelfElement.shelfName = shelfnameTxt.text
        parentViewController.reloadTableData()
        return true;
    }
}