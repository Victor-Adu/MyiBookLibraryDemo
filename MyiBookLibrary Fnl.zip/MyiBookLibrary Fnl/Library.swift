//
//  Library.swift
//  MyiBookLibrary
//
//  Created by Victor  Adu on 7/7/14.
//  Copyright (c) 2014 Victor  Adu. All rights reserved.
//


// Library Element
import Foundation
class Library:NSObject {
    var shelfArray:NSMutableArray!
    var unShelfElement:Shelf!
    init() {
        shelfArray = NSMutableArray()
        unShelfElement = Shelf()
        unShelfElement.shelfName = "UnShelf"
    }
    // Shelf is added in Library
    func addShelf(name : NSString) {
        var shelfElement = Shelf()
        shelfElement.shelfName = name
        shelfArray.addObject(shelfElement)
    }
    // Shelf is removed in Library
    func deleteShelf(index:NSInteger) {
        shelfArray.removeObjectAtIndex(index)
    }
    // Shelf is changed in Library
    func updateShelf(index:NSInteger, name:NSString) {
        var shelfElement = shelfArray.objectAtIndex(index) as Shelf
        shelfElement.shelfName = name
        shelfArray.replaceObjectAtIndex(index, withObject: shelfElement)
    }
}
